-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.11-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para hondumedic
CREATE DATABASE IF NOT EXISTS `hondumedic` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `hondumedic`;

-- Volcando estructura para tabla hondumedic.activostangibles
CREATE TABLE IF NOT EXISTS `activostangibles` (
  `idactivot` int(11) NOT NULL AUTO_INCREMENT,
  `atnombre` text NOT NULL DEFAULT '',
  `atdescripcion` varchar(100) DEFAULT '',
  `atvalorini` float NOT NULL,
  `atdepreciacion` float DEFAULT NULL,
  `atvaloractual` float NOT NULL,
  `atfechaingreso` date NOT NULL DEFAULT '0000-00-00',
  `atfechacompra` date NOT NULL DEFAULT '0000-00-00',
  `attotal` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`idactivot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.alimentos
CREATE TABLE IF NOT EXISTS `alimentos` (
  `codigo_al` varchar(20) NOT NULL DEFAULT '',
  `tipo_al` varchar(50) DEFAULT NULL,
  `nombre_al` varchar(50) DEFAULT NULL,
  `precio_al` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`codigo_al`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.caja
CREATE TABLE IF NOT EXISTS `caja` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `paciente` varchar(50) NOT NULL,
  `fecha` varchar(50) NOT NULL,
  `isv` decimal(10,0) NOT NULL,
  `total` decimal(10,0) NOT NULL,
  `estado_pago` varchar(50) NOT NULL,
  `estado` varchar(50) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.caja_laboratorio
CREATE TABLE IF NOT EXISTS `caja_laboratorio` (
  `idventa` varchar(20) NOT NULL DEFAULT '',
  `isv` varchar(20) NOT NULL,
  `paciente` varchar(20) NOT NULL,
  `fecha` varchar(50) NOT NULL,
  `estado_pago` varchar(20) NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.cirugia
CREATE TABLE IF NOT EXISTS `cirugia` (
  `codigo_cirugia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `Precio` decimal(10,0) NOT NULL,
  PRIMARY KEY (`codigo_cirugia`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.cuentascobrar
CREATE TABLE IF NOT EXISTS `cuentascobrar` (
  `idccobrar` int(11) NOT NULL AUTO_INCREMENT,
  `ccnombre` varchar(50) NOT NULL DEFAULT '',
  `ccdescripcion` varchar(50) DEFAULT '',
  `ccmonto` float NOT NULL DEFAULT 1,
  `ccinteres` float NOT NULL,
  `cctotal` float NOT NULL DEFAULT 1,
  `ccfecha` date NOT NULL DEFAULT '0000-00-00',
  `ccplazo` float NOT NULL DEFAULT 0,
  `ccestado` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`idccobrar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.cuentaspagar
CREATE TABLE IF NOT EXISTS `cuentaspagar` (
  `idcpagar` int(11) NOT NULL AUTO_INCREMENT,
  `ccnombre` varchar(50) NOT NULL DEFAULT '',
  `ccdescripcion` varchar(50) DEFAULT '',
  `ccmonto` float NOT NULL DEFAULT 1,
  `ccinteres` float NOT NULL,
  `cctotal` float NOT NULL DEFAULT 1,
  `ccfecha` date NOT NULL DEFAULT '0000-00-00',
  `ccplazo` float NOT NULL DEFAULT 0,
  `ccestado` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`idcpagar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.detalle_laboratorio
CREATE TABLE IF NOT EXISTS `detalle_laboratorio` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `idventa` varchar(50) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `p_s` varchar(100) NOT NULL,
  `precio` varchar(50) NOT NULL,
  `cantidad` varchar(50) NOT NULL,
  `importe` varchar(50) NOT NULL,
  PRIMARY KEY (`id_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.detalle_test_emergencia
CREATE TABLE IF NOT EXISTS `detalle_test_emergencia` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `idventa` varchar(50) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `p_s` varchar(100) NOT NULL,
  `precio` varchar(50) NOT NULL,
  `cantidad` varchar(50) NOT NULL,
  `importe` varchar(50) NOT NULL,
  PRIMARY KEY (`id_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.detalle_test_endoscopia
CREATE TABLE IF NOT EXISTS `detalle_test_endoscopia` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `idventa` varchar(50) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `p_s` varchar(100) NOT NULL,
  `precio` varchar(50) NOT NULL,
  `cantidad` varchar(50) NOT NULL,
  `importe` varchar(50) NOT NULL,
  PRIMARY KEY (`id_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.detalle_test_hospitalizacion
CREATE TABLE IF NOT EXISTS `detalle_test_hospitalizacion` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `idventa` varchar(50) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `p_s` varchar(100) NOT NULL,
  `precio` varchar(50) NOT NULL,
  `cantidad` varchar(50) NOT NULL,
  `importe` varchar(50) NOT NULL,
  PRIMARY KEY (`id_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.detalle_test_laboratorio
CREATE TABLE IF NOT EXISTS `detalle_test_laboratorio` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `idventa` varchar(50) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `p_s` varchar(100) NOT NULL,
  `precio` varchar(50) NOT NULL,
  `cantidad` varchar(50) NOT NULL,
  `importe` varchar(50) NOT NULL,
  PRIMARY KEY (`id_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.detalle_test_rayosx
CREATE TABLE IF NOT EXISTS `detalle_test_rayosx` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `idventa` varchar(50) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `p_s` varchar(100) NOT NULL,
  `precio` varchar(50) NOT NULL,
  `cantidad` varchar(50) NOT NULL,
  `importe` varchar(50) NOT NULL,
  PRIMARY KEY (`id_detalle`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.edificios
CREATE TABLE IF NOT EXISTS `edificios` (
  `idedificio` int(11) NOT NULL AUTO_INCREMENT,
  `ednombre` text NOT NULL DEFAULT '',
  `eddescripcion` varchar(100) DEFAULT '',
  `edvalorini` float NOT NULL,
  `eddepreciacion` float DEFAULT NULL,
  `edvaloractual` float NOT NULL,
  `edfechaingreso` date NOT NULL DEFAULT '0000-00-00',
  `edtotal` int(11) DEFAULT NULL,
  PRIMARY KEY (`idedificio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.empleado
CREATE TABLE IF NOT EXISTS `empleado` (
  `codigo_empleado` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) NOT NULL,
  `rol` varchar(20) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `telefono` int(3) NOT NULL,
  `tipo_empleado` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.equipomedico
CREATE TABLE IF NOT EXISTS `equipomedico` (
  `idequipo` int(11) NOT NULL AUTO_INCREMENT,
  `eqnombre` varchar(50) NOT NULL DEFAULT '',
  `eqdescripcion` varchar(100) DEFAULT '',
  `eqvalorini` float NOT NULL,
  `eqdepreciacion` float DEFAULT NULL,
  `eqvaloractual` float NOT NULL,
  `eqfechacompra` date NOT NULL DEFAULT '0000-00-00',
  `eqfechaingreso` date NOT NULL DEFAULT '0000-00-00',
  `eqtotal` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`idequipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.gastoadmon
CREATE TABLE IF NOT EXISTS `gastoadmon` (
  `idgadmon` int(11) NOT NULL AUTO_INCREMENT,
  `gadescripcion` text NOT NULL,
  `gavalor` double(10,2) NOT NULL,
  `gafecha` date NOT NULL DEFAULT '0000-00-00',
  `gatotal` float NOT NULL,
  PRIMARY KEY (`idgadmon`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.gastos
CREATE TABLE IF NOT EXISTS `gastos` (
  `idgasto` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` text NOT NULL,
  `gastado` double(10,2) NOT NULL,
  `fecha_gasto` varchar(50) NOT NULL,
  PRIMARY KEY (`idgasto`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.inventario_ambulancia
CREATE TABLE IF NOT EXISTS `inventario_ambulancia` (
  `codigo_ambulancia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_ambulancia`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.inventario_cirugia
CREATE TABLE IF NOT EXISTS `inventario_cirugia` (
  `codigo_cirugia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_cirugia`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.inventario_emergencia
CREATE TABLE IF NOT EXISTS `inventario_emergencia` (
  `codigo_emergencia` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_emergencia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.inventario_endoscopia
CREATE TABLE IF NOT EXISTS `inventario_endoscopia` (
  `codigo_endoscopia` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_endoscopia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.inventario_hospitalizacion
CREATE TABLE IF NOT EXISTS `inventario_hospitalizacion` (
  `codigo_hospitalizacion` varchar(50) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_hospitalizacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.inventario_laboratorio
CREATE TABLE IF NOT EXISTS `inventario_laboratorio` (
  `codigo_laboratorio` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_laboratorio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.inventario_rayosx
CREATE TABLE IF NOT EXISTS `inventario_rayosx` (
  `codigo_rayosx` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_rayosx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.inventario_ultrasonido
CREATE TABLE IF NOT EXISTS `inventario_ultrasonido` (
  `codigo_ultrasonido` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `precio` float NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`codigo_ultrasonido`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.moviliarioequipo
CREATE TABLE IF NOT EXISTS `moviliarioequipo` (
  `idme` int(11) NOT NULL AUTO_INCREMENT,
  `menombre` text NOT NULL DEFAULT '',
  `medescripcion` varchar(100) DEFAULT '',
  `mevalorini` float NOT NULL,
  `medepreciacion` float DEFAULT NULL,
  `mevaloractual` float NOT NULL,
  `mefechacompra` date NOT NULL DEFAULT '0000-00-00',
  `mefechaingreso` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`idme`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.nfactura
CREATE TABLE IF NOT EXISTS `nfactura` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.paciente
CREATE TABLE IF NOT EXISTS `paciente` (
  `codigo_paciente` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `edad` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.prestamos
CREATE TABLE IF NOT EXISTS `prestamos` (
  `idprestamo` int(11) NOT NULL AUTO_INCREMENT,
  `prebanco` varchar(50) NOT NULL DEFAULT '',
  `predescripcion` varchar(100) DEFAULT '',
  `premonto` float NOT NULL,
  `preinteres` float DEFAULT NULL,
  `prevalorpagado` float NOT NULL,
  `preplazo` int(11) NOT NULL DEFAULT 0,
  `prefechadjudicacion` date NOT NULL DEFAULT '0000-00-00',
  `prefechavencimiento` date NOT NULL DEFAULT '0000-00-00',
  `prefechaingreso` date NOT NULL DEFAULT '0000-00-00',
  `pretotal` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`idprestamo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.registro_venta
CREATE TABLE IF NOT EXISTS `registro_venta` (
  `numero` varchar(20) NOT NULL DEFAULT '',
  `total` decimal(10,2) DEFAULT NULL,
  `fecha` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.servicio_ambulancia
CREATE TABLE IF NOT EXISTS `servicio_ambulancia` (
  `codigo_ambulancia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `precio` decimal(10,0) NOT NULL DEFAULT 0,
  PRIMARY KEY (`codigo_ambulancia`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.servicio_emergencia
CREATE TABLE IF NOT EXISTS `servicio_emergencia` (
  `codigo_emergencia` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `precio` decimal(10,0) NOT NULL,
  PRIMARY KEY (`codigo_emergencia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.servicio_endoscopia
CREATE TABLE IF NOT EXISTS `servicio_endoscopia` (
  `codigo_endoscopia` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `precio` decimal(10,0) NOT NULL DEFAULT 0,
  PRIMARY KEY (`codigo_endoscopia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.servicio_hospitalizacion
CREATE TABLE IF NOT EXISTS `servicio_hospitalizacion` (
  `codigo_hospitalizacion` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `precio` decimal(10,0) NOT NULL,
  PRIMARY KEY (`codigo_hospitalizacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.servicio_laboratorio
CREATE TABLE IF NOT EXISTS `servicio_laboratorio` (
  `codigo_laboratorio` varchar(20) NOT NULL DEFAULT '',
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `precio` decimal(10,0) NOT NULL DEFAULT 0,
  PRIMARY KEY (`codigo_laboratorio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.servicio_rayosx
CREATE TABLE IF NOT EXISTS `servicio_rayosx` (
  `codigo_rayosx` varchar(20) NOT NULL DEFAULT 'AUTO_INCREMENT',
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `precio` decimal(10,0) NOT NULL DEFAULT 0,
  PRIMARY KEY (`codigo_rayosx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.servicio_ultrasonido
CREATE TABLE IF NOT EXISTS `servicio_ultrasonido` (
  `codigo_ultrasonido` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `precio` decimal(10,0) NOT NULL DEFAULT 0,
  PRIMARY KEY (`codigo_ultrasonido`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.test_emergencia
CREATE TABLE IF NOT EXISTS `test_emergencia` (
  `codigo` varchar(20) NOT NULL DEFAULT '',
  `paciente` varchar(20) NOT NULL,
  `medico_1` varchar(20) NOT NULL,
  `medico_2` varchar(20) NOT NULL,
  `medico_3` varchar(20) NOT NULL,
  `num_habitacion` varchar(15) NOT NULL,
  `observaciones` varchar(150) DEFAULT NULL,
  `fecha` varchar(50) NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.test_endoscopia
CREATE TABLE IF NOT EXISTS `test_endoscopia` (
  `codigo` varchar(20) NOT NULL DEFAULT '',
  `paciente` varchar(20) NOT NULL,
  `medico_1` varchar(20) NOT NULL,
  `medico_2` varchar(20) NOT NULL,
  `medico_3` varchar(20) NOT NULL,
  `num_habitacion` varchar(15) NOT NULL,
  `observaciones` varchar(150) DEFAULT NULL,
  `fecha` varchar(50) NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.test_hospitalizacion
CREATE TABLE IF NOT EXISTS `test_hospitalizacion` (
  `codigo` varchar(20) NOT NULL DEFAULT '',
  `paciente` varchar(20) NOT NULL,
  `medico_1` varchar(20) NOT NULL,
  `medico_2` varchar(20) DEFAULT NULL,
  `medico_3` varchar(20) DEFAULT NULL,
  `num_habitacion` varchar(15) DEFAULT NULL,
  `observaciones` varchar(150) DEFAULT NULL,
  `fecha` varchar(50) NOT NULL,
  `total` double DEFAULT NULL,
  `estado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.test_laboratorio
CREATE TABLE IF NOT EXISTS `test_laboratorio` (
  `codigo` varchar(20) NOT NULL DEFAULT '',
  `paciente` varchar(20) NOT NULL,
  `medico_1` varchar(20) NOT NULL,
  `medico_2` varchar(20) NOT NULL,
  `medico_3` varchar(20) NOT NULL,
  `num_habitacion` varchar(15) NOT NULL,
  `observaciones` varchar(150) DEFAULT NULL,
  `fecha` varchar(50) NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.test_rayosx
CREATE TABLE IF NOT EXISTS `test_rayosx` (
  `codigo` varchar(20) NOT NULL DEFAULT '',
  `paciente` varchar(20) NOT NULL,
  `medico_1` varchar(20) NOT NULL,
  `medico_2` varchar(20) NOT NULL,
  `medico_3` varchar(20) NOT NULL,
  `num_habitacion` varchar(15) NOT NULL,
  `observaciones` varchar(150) DEFAULT NULL,
  `fecha` varchar(50) NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.unidad_apa
CREATE TABLE IF NOT EXISTS `unidad_apa` (
  `codigo_unidad_apa` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `precio` decimal(10,0) NOT NULL,
  PRIMARY KEY (`codigo_unidad_apa`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `codigo` int(100) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) NOT NULL,
  `fecha_nacimiento` varchar(50) NOT NULL DEFAULT '',
  `sexo` varchar(1) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `unidad` varchar(50) NOT NULL,
  `rol` varchar(20) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla hondumedic.vehiculos
CREATE TABLE IF NOT EXISTS `vehiculos` (
  `idvehiculo` int(11) NOT NULL AUTO_INCREMENT,
  `vehmarca` varchar(50) NOT NULL DEFAULT '',
  `vehmodelo` varchar(50) NOT NULL DEFAULT '',
  `vehanio` int(4) NOT NULL,
  `vehdescripcion` varchar(100) DEFAULT '',
  `vehvalorini` float NOT NULL,
  `vehdepreciacion` float DEFAULT NULL,
  `vehvaloractual` float NOT NULL,
  `vehfechacompra` date NOT NULL,
  `vehfechaingreso` date NOT NULL,
  `vehtotal` float NOT NULL,
  PRIMARY KEY (`idvehiculo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
